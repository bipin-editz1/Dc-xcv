import test from "node:test";
import assert from "node:assert/strict";
import { expectCode, setupWithOwner } from "./helpers.ts";
import { Perm } from "../src/core/permissions.ts";

async function world() {
  const x = await setupWithOwner();
  const { hub } = x;
  const alice = await hub.register("alice", "Alice", "alice-pass-1");
  const bob = await hub.register("bobby", "Bob", "bobby-pass-1");
  const eve = await hub.register("evee", "Eve", "evee-pass-1");
  await hub.login("alice", "alice-pass-1");
  const ws = await hub.createWorkspace("Club");
  const general = (await hub.listChannels(ws.id))[0];
  hub.logout();
  await hub.login("bobby", "bobby-pass-1");
  await hub.joinWorkspace(ws.id);
  hub.logout();
  return { ...x, alice, bob, eve, ws, general };
}

test("members can chat; non-members are denied everything", async () => {
  const { hub, ws, general } = await world();
  await hub.login("bobby", "bobby-pass-1");
  await hub.sendMessage(general.id, "hi all");
  assert.equal((await hub.listMessages(general.id)).length, 1);
  hub.logout();
  await hub.login("evee", "evee-pass-1");
  await expectCode(hub.listChannels(ws.id), "NOT_MEMBER");
  await expectCode(hub.listMessages(general.id), "NOT_MEMBER");
  await expectCode(hub.sendMessage(general.id, "intruder"), "NOT_MEMBER");
});

test("messages persist in order and are validated", async () => {
  const { hub, general } = await world();
  await hub.login("bobby", "bobby-pass-1");
  await hub.sendMessage(general.id, "one");
  await hub.sendMessage(general.id, "two");
  assert.deepEqual((await hub.listMessages(general.id)).map((m) => m.body), ["one", "two"]);
  await expectCode(hub.sendMessage(general.id, "   "), "INVALID_INPUT");
  await expectCode(hub.sendMessage(general.id, "x".repeat(4001)), "INVALID_INPUT");
});

test("plain member cannot manage channels, roles, or others' messages; can delete own", async () => {
  const { hub, ws, general, alice } = await world();
  await hub.login("alice", "alice-pass-1");
  await hub.sendMessage(general.id, "alice msg");
  hub.logout();
  await hub.login("bobby", "bobby-pass-1");
  await hub.sendMessage(general.id, "bob msg");
  const msgs = await hub.listMessages(general.id);
  await expectCode(hub.createChannel(ws.id, "secret"), "FORBIDDEN");
  await expectCode(hub.deleteChannel(general.id), "FORBIDDEN");
  await expectCode(hub.createRole(ws.id, "Boss", Perm.ADMIN), "FORBIDDEN");
  await expectCode(hub.deleteMessage(msgs.find((m) => m.body === "alice msg")!.id), "FORBIDDEN");
  await hub.deleteMessage(msgs.find((m) => m.body === "bob msg")!.id);
  void alice;
});

test("workspace owner can manage channels and moderate messages", async () => {
  const { hub, ws, general } = await world();
  await hub.login("bobby", "bobby-pass-1");
  await hub.sendMessage(general.id, "bob msg");
  hub.logout();
  await hub.login("alice", "alice-pass-1");
  const ch = await hub.createChannel(ws.id, "Random Stuff");
  assert.equal(ch.name, "random-stuff");
  const m = (await hub.listMessages(general.id))[0];
  await hub.deleteMessage(m.id);
  assert.equal((await hub.listMessages(general.id)).length, 0);
});

test("role without SEND cannot send; role without VIEW cannot read", async () => {
  const { hub, ws, general, bob } = await world();
  await hub.login("alice", "alice-pass-1");
  const readOnly = await hub.createRole(ws.id, "ReadOnly", Perm.VIEW);
  await hub.assignRole(ws.id, bob.id, readOnly);
  hub.logout();
  await hub.login("bobby", "bobby-pass-1");
  await expectCode(hub.sendMessage(general.id, "nope"), "FORBIDDEN");
  assert.equal((await hub.listMessages(general.id)).length, 0);
  hub.logout();
  await hub.login("alice", "alice-pass-1");
  const none = await hub.createRole(ws.id, "Muted", 0);
  await hub.assignRole(ws.id, bob.id, none);
  hub.logout();
  await hub.login("bobby", "bobby-pass-1");
  await expectCode(hub.listMessages(general.id), "FORBIDDEN");
});

test("no privilege escalation: a role manager cannot grant ADMIN or permissions they lack", async () => {
  const { hub, ws, bob } = await world();
  await hub.login("alice", "alice-pass-1");
  const mgr = await hub.createRole(ws.id, "RoleManager", Perm.VIEW | Perm.SEND | Perm.MANAGE_ROLES);
  const adminRole = (await hub.listRoles(ws.id)).find((r) => r.name === "Admin")!;
  await hub.assignRole(ws.id, bob.id, mgr);
  hub.logout();
  await hub.login("bobby", "bobby-pass-1");
  await expectCode(hub.createRole(ws.id, "Super", Perm.ADMIN), "FORBIDDEN");
  await expectCode(hub.createRole(ws.id, "Chan", Perm.MANAGE_CHANNELS), "FORBIDDEN");
  await expectCode(hub.assignRole(ws.id, bob.id, adminRole.id), "FORBIDDEN"); // self-promotion
  await expectCode(hub.updateRolePermissions(mgr, Perm.ADMIN), "FORBIDDEN");
  const ok = await hub.createRole(ws.id, "Chatter", Perm.VIEW | Perm.SEND);
  assert.ok(ok);
});

test("a role manager cannot demote the workspace owner", async () => {
  const { hub, ws, bob, alice } = await world();
  await hub.login("alice", "alice-pass-1");
  const mgr = await hub.createRole(ws.id, "RoleManager", Perm.VIEW | Perm.SEND | Perm.MANAGE_ROLES);
  await hub.assignRole(ws.id, bob.id, mgr);
  const memberRole = (await hub.listRoles(ws.id)).find((r) => r.isDefault)!;
  hub.logout();
  await hub.login("bobby", "bobby-pass-1");
  await expectCode(hub.assignRole(ws.id, alice.id, memberRole.id), "FORBIDDEN");
});

test("workspace deletion needs the exact name and the workspace owner", async () => {
  const { hub, ws } = await world();
  await hub.login("bobby", "bobby-pass-1");
  await expectCode(hub.deleteWorkspace(ws.id, "Club"), "FORBIDDEN");
  hub.logout();
  await hub.login("alice", "alice-pass-1");
  await expectCode(hub.deleteWorkspace(ws.id, "wrong"), "CONFIRMATION_FAILED");
  await hub.deleteWorkspace(ws.id, "Club");
  assert.equal((await hub.myWorkspaces()).length, 0);
});

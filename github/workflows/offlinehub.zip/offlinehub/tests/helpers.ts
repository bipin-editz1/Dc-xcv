import { Hub } from "../src/core/hub.ts";
import { NodeDb } from "./nodeDb.ts";

export interface Clock {
  t: number;
  now: () => Date;
}
export function makeClock(start = Date.UTC(2026, 0, 1)): Clock {
  const c: Clock = { t: start, now: () => new Date(c.t) };
  return c;
}

export async function newHub(path = ":memory:", clock = makeClock()) {
  const db = new NodeDb(path);
  const hub = new Hub({ db, now: clock.now, iterations: 1000 }); // low iterations: tests only
  await hub.init();
  return { hub, db, clock };
}

export const OWNER_PW = "owner-password-123";

export async function setupWithOwner(path = ":memory:") {
  const x = await newHub(path);
  await x.hub.setupOwner("boss", "The Boss", OWNER_PW);
  return x;
}

export async function expectCode(p: Promise<unknown>, code: string): Promise<void> {
  try {
    await p;
  } catch (e: any) {
    if (e?.code === code) return;
    throw new Error(`expected error code ${code}, got ${e?.code ?? e}`);
  }
  throw new Error(`expected error code ${code}, but call succeeded`);
}

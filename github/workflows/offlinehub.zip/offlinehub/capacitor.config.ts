import type { CapacitorConfig } from "@capacitor/cli";

// No server.url: the app loads only its bundled files. No remote backend.
const config: CapacitorConfig = {
  appId: "com.offlinehub.app",
  appName: "OfflineHub",
  webDir: "dist",
};

export default config;

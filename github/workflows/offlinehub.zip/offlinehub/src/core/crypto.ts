// Password hashing: PBKDF2-HMAC-SHA512 via WebCrypto (available in Android WebView and Node).
export const DEFAULT_ITERATIONS = 210_000; // OWASP guidance for PBKDF2-HMAC-SHA512

const enc = new TextEncoder();

function toB64(u: Uint8Array): string {
  let s = "";
  for (const b of u) s += String.fromCharCode(b);
  return btoa(s);
}
function fromB64(s: string): Uint8Array<ArrayBuffer> {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function derive(password: string, salt: Uint8Array<ArrayBuffer>, iterations: number): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-512", salt, iterations }, key, 512);
  return new Uint8Array(bits);
}

export interface PasswordRecord {
  hash: string;
  salt: string;
  iterations: number;
}

export async function hashPassword(password: string, iterations = DEFAULT_ITERATIONS): Promise<PasswordRecord> {
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  const hash = await derive(password, salt, iterations);
  return { hash: toB64(hash), salt: toB64(salt), iterations };
}

export async function verifyPassword(password: string, rec: PasswordRecord): Promise<boolean> {
  const got = await derive(password, fromB64(rec.salt), rec.iterations);
  const want = fromB64(rec.hash);
  if (got.length !== want.length) return false;
  let diff = 0;
  for (let i = 0; i < got.length; i++) diff |= got[i] ^ want[i];
  return diff === 0;
}

export function newId(): string {
  return crypto.randomUUID();
}

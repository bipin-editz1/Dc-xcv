export const Perm = {
  VIEW: 1,
  SEND: 2,
  MANAGE_MESSAGES: 4,
  MANAGE_CHANNELS: 8,
  MANAGE_ROLES: 16,
  MANAGE_MEMBERS: 32,
  ADMIN: 64,
} as const;

export const ALL_PERMS = 127;

export const PERM_LABELS: Array<[number, string]> = [
  [Perm.VIEW, "View channels"],
  [Perm.SEND, "Send messages"],
  [Perm.MANAGE_MESSAGES, "Manage messages"],
  [Perm.MANAGE_CHANNELS, "Manage channels"],
  [Perm.MANAGE_ROLES, "Manage roles"],
  [Perm.MANAGE_MEMBERS, "Manage members"],
  [Perm.ADMIN, "Administrator (all)"],
];

/** ADMIN implies every permission. */
export function effective(mask: number): number {
  return (mask & Perm.ADMIN) !== 0 ? ALL_PERMS : mask & ALL_PERMS;
}

export function has(mask: number, perm: number): boolean {
  return (effective(mask) & perm) === perm;
}

/** True if `want` contains no bit that `mine` lacks (anti privilege-escalation). */
export function isSubset(want: number, mine: number): boolean {
  return (want & ~effective(mine) & ALL_PERMS) === 0;
}

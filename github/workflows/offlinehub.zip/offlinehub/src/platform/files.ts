import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";

/** Saves the backup JSON to app cache and opens the Android share sheet (Save to Files / Drive / etc). */
export async function shareBackup(json: string): Promise<void> {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const path = `offlinehub-backup-${stamp}.json`;
  const res = await Filesystem.writeFile({ path, data: json, directory: Directory.Cache, encoding: Encoding.UTF8 });
  await Share.share({ title: "OfflineHub backup", url: res.uri, dialogTitle: "Save your backup" });
}

/** Lets the user pick a backup file; returns its text. */
export function pickTextFile(): Promise<string> {
  return new Promise((resolve, reject) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json,.json";
    input.onchange = () => {
      const f = input.files?.[0];
      if (!f) return reject(new Error("No file chosen"));
      if (f.size > 50 * 1024 * 1024) return reject(new Error("File is too large"));
      f.text().then(resolve, reject);
    };
    input.click();
  });
}

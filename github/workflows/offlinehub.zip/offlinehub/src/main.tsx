import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Hub } from "./core/hub.ts";
import { openDeviceDb } from "./platform/capacitorDb.ts";
import { App } from "./App.tsx";
import "./styles.css";

const root = createRoot(document.getElementById("root")!);

async function boot() {
  try {
    const db = await openDeviceDb();
    const hub = new Hub({ db });
    await hub.init();
    root.render(
      <StrictMode>
        <App hub={hub} />
      </StrictMode>,
    );
  } catch (e) {
    // Shown on screen so a startup problem is visible without a debugger.
    root.render(
      <div className="center">
        <div className="card stack">
          <h2>Startup problem</h2>
          <div className="err">{e instanceof Error ? e.message : String(e)}</div>
          <div className="note">Please take a screenshot of this message.</div>
        </div>
      </div>,
    );
  }
}
void boot();

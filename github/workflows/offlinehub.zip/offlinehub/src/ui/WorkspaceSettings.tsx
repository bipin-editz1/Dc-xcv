import { useCallback, useEffect, useState } from "react";
import type { Hub, PublicUser } from "../core/hub.ts";
import { PERM_LABELS } from "../core/permissions.ts";
import { Modal, useAction } from "./common.tsx";

type Role = { id: string; name: string; permissions: number; isDefault: boolean };
type Member = { userId: string; displayName: string; roleId: string; roleName: string };

export function WorkspaceSettings(props: { hub: Hub; ws: { id: string; name: string }; user: PublicUser; onClose: () => void; onDeleted: () => void }) {
  const { hub, ws } = props;
  const [roles, setRoles] = useState<Role[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [newRole, setNewRole] = useState("");
  const [confirm, setConfirm] = useState("");
  const a = useAction();

  const load = useCallback(async () => {
    setRoles(await hub.listRoles(ws.id));
    setMembers(await hub.listMembers(ws.id));
  }, [hub, ws.id]);
  useEffect(() => { void a.run(load); }, [load]);

  async function toggle(r: Role, bit: number) {
    await a.run(async () => { await hub.updateRolePermissions(r.id, r.permissions ^ bit); await load(); });
  }

  return (
    <Modal title={`${ws.name} · settings`} onClose={props.onClose}>
      {a.error && <div className="err">{a.error}</div>}
      <h3>Members</h3>
      {members.map((m) => (
        <div className="table-row" key={m.userId}>
          <div className="grow">{m.displayName}</div>
          <select className="fit" style={{ width: 140 }} value={m.roleId} onChange={(e) => a.run(async () => { await hub.assignRole(ws.id, m.userId, e.target.value); await load(); })}>
            {roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        </div>
      ))}
      <h3 style={{ marginTop: 16 }}>Roles & permissions</h3>
      <div className="note">Changes are checked on every action. You cannot grant permissions you do not have.</div>
      {roles.map((r) => (
        <div key={r.id} style={{ margin: "10px 0", padding: 10, border: "1px solid var(--border)", borderRadius: 8 }}>
          <div className="row"><strong>{r.name}{r.isDefault ? " (default)" : ""}</strong>
            {!r.isDefault && <button className="ghost fit" onClick={() => a.run(async () => { await hub.deleteRole(r.id); await load(); })}>delete</button>}</div>
          {PERM_LABELS.map(([bit, label]) => (
            <label key={bit} style={{ display: "flex", gap: 8, alignItems: "center", margin: "4px 0", color: "var(--text)" }}>
              <input type="checkbox" style={{ width: "auto" }} checked={(r.permissions & bit) !== 0} onChange={() => toggle(r, bit)} /> {label}
            </label>
          ))}
        </div>
      ))}
      <div className="row"><input placeholder="New role name" value={newRole} onChange={(e) => setNewRole(e.target.value)} />
        <button className="fit" onClick={() => a.run(async () => { await hub.createRole(ws.id, newRole, 3); setNewRole(""); await load(); })}>Add role</button></div>
      <h3 style={{ marginTop: 20 }}>Danger zone</h3>
      <div className="note">Type the workspace name “{ws.name}” to delete it and all its messages.</div>
      <input value={confirm} onChange={(e) => setConfirm(e.target.value)} style={{ marginTop: 6 }} />
      <button className="danger" style={{ width: "100%", marginTop: 8 }} disabled={confirm !== ws.name} onClick={async () => { const ok = await a.run(async () => { await hub.deleteWorkspace(ws.id, confirm); return true; }); if (ok) props.onDeleted(); }}>Delete workspace</button>
    </Modal>
  );
}

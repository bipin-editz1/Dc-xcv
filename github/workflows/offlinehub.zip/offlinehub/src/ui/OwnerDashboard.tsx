import { useCallback, useEffect, useState } from "react";
import { AppError } from "../core/db.ts";
import type { Branding, Hub, PublicUser, Status } from "../core/hub.ts";
import { displayedMemberSince } from "../core/hub.ts";
import { pickTextFile, shareBackup } from "../platform/files.ts";
import { Modal, errMsg, fmtDate, fmtDateTime, randomPassword } from "./common.tsx";

type Tab = "accounts" | "tests" | "audit" | "backup" | "brand";
const TABS: Array<[Tab, string]> = [["accounts", "Accounts"], ["tests", "Test accounts"], ["audit", "Audit log"], ["backup", "Backup"], ["brand", "Branding"]];

interface Props {
  hub: Hub;
  brand: Branding;
  onClose: () => void;
  onBrand: () => Promise<void>;
  onRestored: () => void;
}

export function OwnerDashboard(props: Props) {
  const { hub } = props;
  const [locked, setLocked] = useState(!hub.isAdminUnlocked());
  const [tab, setTab] = useState<Tab>("accounts");
  const [pw, setPw] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  /** Runs an owner action; re-prompts for the password if the admin session expired. */
  const guard = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    setError("");
    try {
      return await fn();
    } catch (e) {
      if (e instanceof AppError && e.code === "ADMIN_LOCKED") setLocked(true);
      else setError(errMsg(e));
      return undefined;
    }
  }, []);

  if (locked) {
    return (
      <Modal title="Owner dashboard" onClose={props.onClose}>
        <div className="note">Re-enter your Owner password to unlock administrative actions (they re-lock after 5 minutes).</div>
        <input type="password" placeholder="Owner password" value={pw} onChange={(e) => setPw(e.target.value)} style={{ marginTop: 10 }} />
        {error && <div className="err">{error}</div>}
        <button className="primary" style={{ width: "100%", marginTop: 12 }} onClick={async () => { const ok = await guard(async () => { await hub.unlockAdmin(pw); return true; }); if (ok) { setPw(""); setLocked(false); } }}>Unlock</button>
      </Modal>
    );
  }

  return (
    <Modal title="Owner dashboard" onClose={() => { hub.lockAdmin(); props.onClose(); }}>
      <div className="tabs">{TABS.map(([k, l]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => { setTab(k); setError(""); setInfo(""); }}>{l}</button>)}</div>
      {error && <div className="err">{error}</div>}
      {info && <div className="note" style={{ color: "var(--ok)" }}>{info}</div>}
      {tab === "accounts" && <Accounts hub={hub} guard={guard} setInfo={setInfo} />}
      {tab === "tests" && <TestAccounts hub={hub} guard={guard} setInfo={setInfo} />}
      {tab === "audit" && <Audit hub={hub} guard={guard} />}
      {tab === "backup" && <Backup hub={hub} guard={guard} setInfo={setInfo} onRestored={props.onRestored} />}
      {tab === "brand" && <BrandTab hub={hub} brand={props.brand} guard={guard} setInfo={setInfo} onBrand={props.onBrand} />}
    </Modal>
  );
}

type Guard = <T>(fn: () => Promise<T>) => Promise<T | undefined>;
type Common = { hub: Hub; guard: Guard; setInfo: (s: string) => void };

function Accounts({ hub, guard, setInfo }: Common) {
  const [users, setUsers] = useState<PublicUser[]>([]);
  const [sel, setSel] = useState<PublicUser | null>(null);
  const [nu, setNu] = useState({ username: "", displayName: "", password: "", memberSince: "" });
  const load = useCallback(async () => { const l = await guard(() => hub.listUsers()); if (l) setUsers(l); }, [hub, guard]);
  useEffect(() => { void load(); }, [load]);

  if (sel) return <UserDetail hub={hub} guard={guard} setInfo={setInfo} user={sel} onBack={() => { setSel(null); void load(); }} />;
  return (
    <div>
      <h3>Create account</h3>
      <div className="stack">
        <input placeholder="Username" autoCapitalize="none" value={nu.username} onChange={(e) => setNu({ ...nu, username: e.target.value })} />
        <input placeholder="Display name" value={nu.displayName} onChange={(e) => setNu({ ...nu, displayName: e.target.value })} />
        <input placeholder="Password (8+)" value={nu.password} onChange={(e) => setNu({ ...nu, password: e.target.value })} />
        <label>Displayed “Member since” (optional)</label>
        <input type="date" value={nu.memberSince} onChange={(e) => setNu({ ...nu, memberSince: e.target.value })} />
        <button className="primary" style={{ width: "100%" }} onClick={async () => { const u = await guard(() => hub.createUser({ username: nu.username, displayName: nu.displayName || nu.username, password: nu.password, memberSince: nu.memberSince || null })); if (u) { setInfo(`Created ${u.username}`); setNu({ username: "", displayName: "", password: "", memberSince: "" }); await load(); } }}>Create</button>
      </div>
      <h3 style={{ marginTop: 18 }}>All accounts ({users.length})</h3>
      {users.map((u) => (
        <div className="table-row" key={u.id} onClick={() => setSel(u)} style={{ cursor: "pointer" }}>
          <div className="grow">{u.displayName} <span className="note">@{u.username}</span>
            {u.isOwner && <span className="badge">owner</span>}{u.isTest && <span className="badge">test</span>}{u.status !== "active" && <span className="badge bad">{u.status}</span>}</div>
          <span className="note">›</span>
        </div>
      ))}
    </div>
  );
}

function UserDetail(props: Common & { user: PublicUser; onBack: () => void }) {
  const { hub, guard, setInfo } = props;
  const [u, setU] = useState(props.user);
  const [display, setDisplay] = useState(u.displayName);
  const [username, setUsername] = useState(u.username);
  const [date, setDate] = useState(u.memberSinceDisplay ? u.memberSinceDisplay.slice(0, 10) : "");
  const [newPw, setNewPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [armed, setArmed] = useState<null | "ban" | "delete">(null);

  async function reload() {
    const l = await guard(() => hub.listUsers());
    const f = l?.find((x) => x.id === u.id);
    if (f) setU(f);
  }
  async function status(s: Status) {
    if (await guard(async () => { await hub.setStatus(u.id, s); return true; })) { setInfo(`Status: ${s}`); await reload(); }
  }

  return (
    <div className="stack">
      <button className="ghost" onClick={props.onBack}>‹ Back</button>
      <h3>{u.displayName} <span className="note">@{u.username}</span></h3>
      <div className="note">Status: {u.status}{u.isOwner ? " · Owner" : ""}{u.isTest ? " · test account" : ""}</div>
      <div className="note">Real creation time (cannot be edited): {fmtDateTime(u.createdAt)}</div>
      <div className="note">Displayed “Member since”: {fmtDate(displayedMemberSince(u))}</div>

      <label>Username</label><input value={username} autoCapitalize="none" onChange={(e) => setUsername(e.target.value)} />
      <label>Display name</label><input value={display} onChange={(e) => setDisplay(e.target.value)} />
      <button onClick={async () => { if (await guard(async () => { await hub.updateUser(u.id, { username, displayName: display }); return true; })) { setInfo("Saved"); await reload(); } }}>Save name changes</button>

      <label>Displayed “Member since” date (cosmetic only)</label>
      <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      <div className="row">
        <button onClick={async () => { if (await guard(async () => { await hub.setMemberSince(u.id, date || null); return true; })) { setInfo("Displayed date updated"); await reload(); } }}>Set displayed date</button>
        <button onClick={async () => { if (await guard(async () => { await hub.setMemberSince(u.id, null); return true; })) { setDate(""); setInfo("Now showing the real date"); await reload(); } }}>Use real date</button>
      </div>

      <label>Reset password</label>
      <div className="row"><input type="text" value={newPw} placeholder="New password" onChange={(e) => setNewPw(e.target.value)} /><button className="fit" onClick={async () => { if (await guard(async () => { await hub.resetPassword(u.id, newPw); return true; })) { setNewPw(""); setInfo("Password reset"); } }}>Reset</button></div>

      {!u.isOwner && (<>
        <div className="row">
          <button onClick={() => status("suspended")} disabled={u.status === "suspended"}>Suspend</button>
          <button className="danger" onClick={() => setArmed(armed === "ban" ? null : "ban")} disabled={u.status === "banned"}>Ban…</button>
          <button onClick={() => status("active")} disabled={u.status === "active"}>Restore</button>
        </div>
        {armed === "ban" && <div className="card" style={{ maxWidth: "none" }}><div className="note">Banned accounts cannot log in. You can restore them later.</div><button className="danger" style={{ width: "100%", marginTop: 8 }} onClick={async () => { setArmed(null); await status("banned"); }}>Yes, ban this account</button></div>}
        <button className="danger" onClick={() => setArmed(armed === "delete" ? null : "delete")}>Delete account…</button>
        {armed === "delete" && (
          <div className="card" style={{ maxWidth: "none" }}>
            <div className="note">This permanently deletes the account. Their old messages stay, shown with their name. Type <strong>{u.username}</strong> to confirm.</div>
            <input value={confirm} onChange={(e) => setConfirm(e.target.value)} style={{ marginTop: 8 }} />
            <button className="danger" style={{ width: "100%", marginTop: 8 }} disabled={confirm !== u.username} onClick={async () => { if (await guard(async () => { await hub.deleteUser(u.id, confirm); return true; })) { setInfo("Account deleted"); props.onBack(); } }}>Delete permanently</button>
          </div>
        )}
      </>)}
    </div>
  );
}

function TestAccounts({ hub, guard, setInfo }: Common) {
  const [count, setCount] = useState("10");
  const [prefix, setPrefix] = useState("tester");
  const [pw, setPw] = useState(randomPassword());
  const [date, setDate] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState("");
  return (
    <div className="stack">
      <div className="note">Creates local test accounts (flagged “test”). They all get the password below. Up to 200 per batch.</div>
      <label>How many</label><input inputMode="numeric" value={count} onChange={(e) => setCount(e.target.value)} />
      <label>Username prefix</label><input value={prefix} autoCapitalize="none" onChange={(e) => setPrefix(e.target.value)} />
      <label>Shared password</label>
      <div className="row"><input value={pw} onChange={(e) => setPw(e.target.value)} /><button className="fit" onClick={() => setPw(randomPassword())}>New</button></div>
      <label>Displayed “Member since” (optional)</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      <button className="primary" disabled={busy} onClick={async () => { setBusy(true); const names = await guard(() => hub.generateTestAccounts({ count: Number(count), prefix, password: pw, memberSince: date || null })); setBusy(false); if (names) setInfo(`Created ${names.length} accounts: ${names[0]} … ${names[names.length - 1]}`); }}>{busy ? "Creating… (this can take a while)" : "Generate"}</button>
      <h3 style={{ marginTop: 16 }}>Delete all test accounts</h3>
      <div className="note">Type DELETE TEST ACCOUNTS to confirm.</div>
      <input value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      <button className="danger" disabled={confirm !== "DELETE TEST ACCOUNTS"} onClick={async () => { const n = await guard(() => hub.deleteAllTestAccounts(confirm)); if (n !== undefined) { setInfo(`Deleted ${n} test accounts`); setConfirm(""); } }}>Delete all test accounts</button>
    </div>
  );
}

function Audit({ hub, guard }: { hub: Hub; guard: Guard }) {
  const [rows, setRows] = useState<Awaited<ReturnType<Hub["listAudit"]>>>([]);
  useEffect(() => { void guard(() => hub.listAudit(300)).then((r) => r && setRows(r)); }, [hub, guard]);
  return (
    <div>
      <div className="note">Newest first. The log records who did what; it cannot be edited from the app.</div>
      {rows.map((r) => (
        <div className="table-row" key={r.seq}><div className="grow"><strong>{r.action}</strong> {r.target && <>→ {r.target}</>}<div className="note">{r.actorName} · {fmtDateTime(r.createdAt)}{r.detail ? ` · ${r.detail}` : ""}</div></div></div>
      ))}
    </div>
  );
}

function Backup({ hub, guard, setInfo, onRestored }: Common & { onRestored: () => void }) {
  const [confirm, setConfirm] = useState("");
  return (
    <div className="stack">
      <h3>Export backup</h3>
      <div className="note">The backup contains all accounts (including password hashes), messages and the audit log. Keep the file private.</div>
      <button className="primary" onClick={async () => { const ok = await guard(async () => { await shareBackup(await hub.exportBackup()); return true; }); if (ok) setInfo("Backup created"); }}>Create backup & share</button>
      <h3 style={{ marginTop: 16 }}>Restore backup</h3>
      <div className="note">Replaces ALL current data with the backup. Type RESTORE, then choose the file. You will be logged out.</div>
      <input value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      <button className="danger" disabled={confirm !== "RESTORE"} onClick={async () => { const done = await guard(async () => { const text = await pickTextFile(); await hub.restoreBackup(text, confirm); return true; }); if (done) onRestored(); }}>Choose backup file & restore</button>
    </div>
  );
}

function BrandTab({ hub, brand, guard, setInfo, onBrand }: Common & { brand: Branding; onBrand: () => Promise<void> }) {
  const [name, setName] = useState(brand.name);
  const [tagline, setTagline] = useState(brand.tagline);
  const [accent, setAccent] = useState(brand.accent);
  const [logo, setLogo] = useState<string | null>(brand.logo);

  function chooseLogo() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/png,image/jpeg,image/webp";
    input.onchange = () => {
      const f = input.files?.[0];
      if (!f) return;
      const r = new FileReader();
      r.onload = () => setLogo(String(r.result));
      r.readAsDataURL(f);
    };
    input.click();
  }

  return (
    <div className="stack">
      <label>App name</label><input value={name} onChange={(e) => setName(e.target.value)} />
      <label>Tagline</label><input value={tagline} onChange={(e) => setTagline(e.target.value)} />
      <label>Accent color</label>
      <div className="row"><input type="color" value={accent} onChange={(e) => setAccent(e.target.value)} style={{ height: 44 }} /><input value={accent} onChange={(e) => setAccent(e.target.value)} /></div>
      <label>Logo (PNG/JPEG/WebP, max ~200 KB)</label>
      <div className="row">{logo ? <img src={logo} alt="" style={{ width: 48, height: 48, borderRadius: 10, objectFit: "cover", flex: "0 0 auto" }} /> : <span className="note">No logo</span>}<button onClick={chooseLogo}>Choose image</button>{logo && <button className="ghost" onClick={() => setLogo(null)}>Remove</button>}</div>
      <button className="primary" onClick={async () => { const b = await guard(() => hub.setBranding({ name, tagline, accent, logo })); if (b) { await onBrand(); setInfo("Branding saved"); } }}>Save branding</button>
    </div>
  );
}

# OfflineHub

Standalone, offline Android chat app (React + TypeScript + Capacitor + SQLite). Original code: it is NOT derived from Concord
(the Concord zip has no LICENSE file, so none of its code was copied).

## What works offline
Local accounts, profiles, multiple workspaces, text channels, persistent messages, roles + permissions, Owner dashboard
(create/edit/suspend/ban/restore/delete accounts, test-account batches, editable displayed "Member Since", audit log),
backup/restore, configurable branding. There is no server, no cloud login and no network call anywhere in `src/`
(a test scans the source for fetch/XHR/WebSocket/URLs).

## Commands
    npm install
    npm test            # 27 logic tests on real SQLite (Node 22+)
    npm run build       # type-check + web build
    npx cap add android && npx cap sync android
    cd android && ./gradlew assembleDebug   # needs Java 17 + Android SDK
APK output: android/app/build/outputs/apk/debug/app-debug.apk

## Security model and honest limits
- First run creates the Owner with a password you choose. No default password or PIN exists. A forgotten Owner password cannot be recovered.
- Passwords: PBKDF2-HMAC-SHA512, 210,000 iterations, random 16-byte salt, constant-time compare.
- Owner actions need the Owner session AND a password re-entry (auto-locks after 5 min). Every privileged method re-checks this itself, not just the UI.
- Role changes cannot grant permissions the actor lacks; nobody can promote themselves.
- "Member Since" edit changes only a display field. The real `created_at` is never updated by any code path; both are shown in the Owner dashboard and the change is audited.
- NOT implemented yet: database encryption with an Android Keystore key. The database file is in app-private storage but is not encrypted.
- Whoever controls the device (root, a modified APK, an ADB backup) can read or alter the data and bypass these checks. The audit log is not tamper-proof. Backups contain password hashes: keep them private.
- Local accounts are not Discord accounts; there is no online/presence status.
